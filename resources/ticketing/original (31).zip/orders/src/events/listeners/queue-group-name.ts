export const queueGroupName = 'orders-service';
