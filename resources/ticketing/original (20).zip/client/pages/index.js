export default () => {
  return <h1>Landing Page</h1>;
};
